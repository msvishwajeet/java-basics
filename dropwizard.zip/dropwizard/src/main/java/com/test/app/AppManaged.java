package com.test.app;

import io.dropwizard.lifecycle.Managed;

public class AppManaged implements Managed {

    @Override
    public void start() throws Exception {
        // spring context
    }

    @Override
    public void stop() throws Exception {

    }

}
