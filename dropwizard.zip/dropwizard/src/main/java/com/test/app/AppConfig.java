package com.test.app;

import io.dropwizard.Configuration;

public class AppConfig extends Configuration {

    public String getMysql() {
        return mysql;
    }

    public void setMysql(String mysql) {
        this.mysql = mysql;
    }

    private String mysql;

}
