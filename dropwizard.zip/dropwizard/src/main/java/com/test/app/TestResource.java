package com.test.app;


import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.HashMap;
import java.util.Map;

@Path("/test1")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class TestResource {
    private Object serviceObj;

    public TestResource() {
        //serviceObj = from app context of spring
    }

    @GET
    @Path("/{field}")
    public Response getResult(@PathParam("field") String field, @QueryParam("limit") Integer limit) {
        Map<String, Object> res = new HashMap<>();
        res.put("name", "nitish");
        res.put("status", "success");
        res.put("field", field);
        res.put("limit", limit);

        return Response.ok(res).build();
    }

}
